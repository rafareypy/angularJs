package br.com.api.listatelefonica.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.listatelefonica.model.Operadora;
import br.com.api.listatelefonica.service.OperadoraService;


@RestController
public class OperadorasController {

	@Autowired
	OperadoraService operadoraService;

	@RequestMapping(method = RequestMethod.POST, value = "/operadoras", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Operadora> cadastrarOperadora(@RequestBody Operadora operadora) {
		return new ResponseEntity<>(this.operadoraService.cadastrar(operadora), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/operadoras/{serial}")
	public ResponseEntity<Operadora> excluirOperadora(@RequestBody String serial) {

		Operadora operadoraEncontrado = this.operadoraService.buscaOperadoraPorSerial(serial);
		if (operadoraEncontrado != null) {
			this.operadoraService.remover(operadoraEncontrado);
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(method = RequestMethod.GET, value = "/operadoras/{serial}")
	public ResponseEntity<Operadora> buscarOperadora(@RequestBody String serial) {
		return new ResponseEntity<>(this.operadoraService.buscaOperadoraPorSerial(serial), HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:8080")	
	@RequestMapping(method = RequestMethod.GET, value = "/operadoras")
	public ResponseEntity<List<Operadora>> buscaOperadoras() {
		return new ResponseEntity<>(this.operadoraService.listaroperadoras() , HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(method = RequestMethod.GET, value = "/teste")
	public void teste() {
		System.out.println("teste");
	}

}
