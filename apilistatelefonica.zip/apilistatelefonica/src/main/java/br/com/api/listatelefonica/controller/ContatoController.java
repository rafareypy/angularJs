package br.com.api.listatelefonica.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.listatelefonica.model.Contato;
import br.com.api.listatelefonica.service.ContatoService;

@RestController
public class ContatoController {

	@Autowired
	ContatoService contatoService;

	@RequestMapping(method = RequestMethod.POST, value = "/contatos", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Contato> cadastrarContato(@RequestBody Contato contato) {
		return new ResponseEntity<>(this.contatoService.cadastrar(contato), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/contatos/{serial}")
	public ResponseEntity<Contato> excluirContato(@RequestBody String serial) {

		Contato ContatoEncontrado = this.contatoService.buscaContatoPorSerial(serial);
		if (ContatoEncontrado != null) {
			this.contatoService.remover(ContatoEncontrado);
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(method = RequestMethod.GET, value = "/contatos/{serial}")
	public ResponseEntity<Contato> buscarContato(@RequestBody String serial) {
		return new ResponseEntity<>(this.contatoService.buscaContatoPorSerial(serial), HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(method = RequestMethod.GET, value = "/contatos")
	public ResponseEntity<List<Contato>> buscaContatos() {
		return new ResponseEntity<>(this.contatoService.listarContatos(), HttpStatus.OK);
	}

}
