package br.com.api.listatelefonica.service;

import static org.mockito.Matchers.contains;

import java.sql.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import br.com.api.listatelefonica.model.Contato;
import br.com.api.listatelefonica.model.Operadora;

@Service
public class ContatoService {

	
	
	Map<String, Contato> contatos = new HashMap<>();
	Long proximoId = 0L;

	public ContatoService(){
		
		Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		
		for(long i =0 ; i < 8 ; i++){
			Contato contato = new Contato();
			contato.setSerial(""+i);
			contato.setData(date);
			contato.setTelefone("1234-123" + i);
			contato.setOperadora(new Operadora(i, "operadora_"+i));
			contatos.put(contato.getSerial(), contato);
		}
		
	}
	
	public Contato cadastrar(Contato contato) {
		proximoId++;
		contato.setSerial(proximoId.toString());
		contatos.put(contato.getSerial(), contato);

		return contato;

	}

	public List<Contato> listarContatos() {

		LinkedList<Contato> listaContatos = new LinkedList<Contato>();
		for (String serial : this.contatos.keySet()) {
			listaContatos.add(this.contatos.get(serial));
		}
		return listaContatos;
	}

	public Boolean remover(Contato contato) {
		try {
			this.contatos.remove(contato);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public Contato buscaContatoPorSerial(String serial) {
		return contatos.get(serial);				
	}

}
