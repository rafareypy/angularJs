package br.com.api.listatelefonica.service;

import java.sql.Date;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import br.com.api.listatelefonica.model.Operadora;

@Service
public class OperadoraService {

	Map<Long, Operadora> operadoras = new HashMap<>();
	Long proximoId = 0L;

	public OperadoraService() {
		for (long i = 0; i < 8; i++) {
			Operadora operadora = new Operadora(i, "operadora_" + i);
			operadoras.put(operadora.getCodigo(), operadora);
		}
	}

	public Operadora cadastrar(Operadora operadora) {
		proximoId++;
		operadora.setCodigo(proximoId);
		operadoras.put(operadora.getCodigo(), operadora);

		return operadora;
	}

	public List<Operadora> listaroperadoras() {

		LinkedList<Operadora> listaoperadoras = new LinkedList<Operadora>();
		for (Long codigo : this.operadoras.keySet()) {
			listaoperadoras.add(this.operadoras.get(codigo));
		}
		return listaoperadoras;
	}

	public Boolean remover(Operadora operadora) {
		try {
			this.operadoras.remove(operadora);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public Operadora buscaOperadoraPorSerial(String serial) {
		return operadoras.get(serial);
	}

}
