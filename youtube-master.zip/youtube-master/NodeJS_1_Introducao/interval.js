console.log("Hello ");
setInterval(function () {
  console.log("World");
}, 2000);