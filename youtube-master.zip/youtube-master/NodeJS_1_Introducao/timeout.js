console.log("Hello ");
setTimeout(function () {
  console.log("World");
}, 2000);