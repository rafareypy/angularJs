var b = require('./b');

b.helloWorld();