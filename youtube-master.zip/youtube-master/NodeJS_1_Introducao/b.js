var helloWorld = function () {
	console.log("Hello World");
};

module.exports = {
	helloWorld: helloWorld
};