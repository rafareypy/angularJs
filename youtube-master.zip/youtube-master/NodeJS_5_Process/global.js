Object.keys(global).forEach(function (value) {
	console.log(value);
});