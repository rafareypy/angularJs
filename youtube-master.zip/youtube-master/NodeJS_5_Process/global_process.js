Object.keys(process).forEach(function (value) {
	console.log(value);
});