console.time('T');
setTimeout(function () {
	console.timeEnd('T');
}, 0);