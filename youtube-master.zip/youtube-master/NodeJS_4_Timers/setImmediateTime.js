console.time('I');
setImmediate(function () {
	console.timeEnd('I');
});