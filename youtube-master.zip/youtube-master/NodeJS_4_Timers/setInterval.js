setInterval(function () {
	console.log('I ' + new Date());
}, 1000);