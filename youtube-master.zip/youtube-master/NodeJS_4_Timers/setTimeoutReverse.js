setTimeout(function () {
	console.log('B ' + new Date());
}, 3000);
console.log('A ' + new Date());