console.log(module.exports === exports);
console.log(module.exports === this);
console.log(exports === this);

console.log(arguments);