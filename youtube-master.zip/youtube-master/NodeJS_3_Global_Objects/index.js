var serialGenerator = require('./serialGenerator');
console.log(serialGenerator.generate());